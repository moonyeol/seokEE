 # seokEE
seokEE(석이) 는 회의 기록 어플리케이션이다. 경기대학교 컴퓨터과학과 캡스톤디자인, Out of Range 팀의 프로젝트이다.
